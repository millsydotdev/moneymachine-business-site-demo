# Turnkey Enterprise React 19 + TypeScript Starter Kit

A production-grade, enterprise-ready React 19 starter boilerplate engineered for speed, clean architecture, and type safety.

## Key Features
- **React 19 & TypeScript 5.7**: Strict TypeScript configuration with zero compiler warnings.
- **Fast Bundling**: Vite 6 bundler configured for sub-second hot module replacement.
- **Modular Component Primitives**: Accessible Button, Card, Badge, Modal, Input, and Table components.
- **Theme & Auth Architecture**: Pre-wired dark/light theme switching and session-based authentication context.
- **Persistence Hooks**: `useLocalStorage` and `useDebounce` with full TypeScript inference.
- **Responsive Layout**: Collapsible enterprise dashboard navigation with mobile drawer support.
- **Typed API Service**: Structured API client with request interceptors, typed response contracts, and offline fallback data.

## Getting Started
See [SETUP_GUIDE.md](./SETUP_GUIDE.md) for step-by-step installation instructions.

```bash
bun install
bun run dev
```

## License
Commercial Perpetual License. See [LICENSE.txt](./LICENSE.txt).
