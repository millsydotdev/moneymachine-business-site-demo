import React, { useState, useEffect } from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Table, Column } from '../components/ui/Table';
import { MetricCardData, ProjectSummary } from '../types';
import { apiClient } from '../services/apiClient';
import { ArrowUpRight, ArrowDownRight, Plus, RefreshCw } from 'lucide-react';

export const DashboardOverview: React.FC = () => {
  const [metrics, setMetrics] = useState<MetricCardData[]>([]);
  const [projects, setProjects] = useState<ProjectSummary[]>([]);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    const [mRes, pRes] = await Promise.all([
      apiClient.getDashboardMetrics(),
      apiClient.getProjects(),
    ]);
    if (mRes.data) setMetrics(mRes.data);
    if (pRes.data) setProjects(pRes.data);
    setLoading(false);
  };

  useEffect(() => {
    loadData();
  }, []);

  const projectColumns: Column<ProjectSummary>[] = [
    { key: 'name', header: 'Project Name', width: '25%' },
    { key: 'teamLead', header: 'Lead Architect', width: '20%' },
    {
      key: 'status',
      header: 'Deployment Status',
      width: '18%',
      render: (p) => (
        <Badge variant={p.status === 'active' ? 'success' : 'warning'}>
          {p.status.replace('_', ' ')}
        </Badge>
      ),
    },
    {
      key: 'budget',
      header: 'Budget / Spent',
      width: '20%',
      render: (p) => (
        <span style={{ fontFamily: 'var(--font-mono)' }}>
          ${p.spent.toLocaleString()} / ${p.budget.toLocaleString()}
        </span>
      ),
    },
    {
      key: 'progress',
      header: 'Progress',
      align: 'right',
      render: (p) => (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '8px' }}>
          <div style={{ width: '80px', height: '6px', backgroundColor: 'var(--border-color)', borderRadius: '3px', overflow: 'hidden' }}>
            <div style={{ width: `${p.progress}%`, height: '100%', backgroundColor: 'var(--accent-emerald)' }} />
          </div>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', width: '32px' }}>{p.progress}%</span>
        </div>
      ),
    },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Page Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '24px', fontWeight: 800, color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>
            Enterprise Dashboard Overview
          </h2>
          <p style={{ fontSize: '14px', color: 'var(--text-muted)', marginTop: '4px' }}>
            Real-time telemetry, service status, and operational health metrics.
          </p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <Button variant="secondary" size="sm" onClick={loadData} isLoading={loading}>
            <RefreshCw size={14} /> Refresh
          </Button>
          <Button variant="primary" size="sm">
            <Plus size={14} /> New Project
          </Button>
        </div>
      </div>

      {/* Metrics Row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '16px' }}>
        {metrics.map((m) => (
          <Card key={m.id}>
            <span style={{ fontSize: '12px', fontFamily: 'var(--font-mono)', textTransform: 'uppercase', color: 'var(--text-muted)' }}>
              {m.title}
            </span>
            <div style={{ fontSize: '26px', fontWeight: 800, color: 'var(--text-primary)', marginTop: '6px', fontFamily: 'var(--font-mono)' }}>
              {m.value}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginTop: '10px', fontSize: '12px' }}>
              <span
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '2px',
                  fontWeight: 600,
                  color: m.changePercent >= 0 ? 'var(--accent-emerald)' : 'var(--accent-crimson)',
                  fontFamily: 'var(--font-mono)',
                }}
              >
                {m.changePercent >= 0 ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                {Math.abs(m.changePercent)}%
              </span>
              <span style={{ color: 'var(--text-muted)' }}>{m.subtext}</span>
            </div>
          </Card>
        ))}
      </div>

      {/* Active Projects Table */}
      <Card
        title="Active Strategic Projects"
        subtitle="Current enterprise workstreams managed under this starter architecture."
      >
        <Table
          columns={projectColumns}
          data={projects}
          keyExtractor={(p) => p.id}
          emptyMessage="No active projects configured."
        />
      </Card>
    </div>
  );
};
