import React, { useState } from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Modal } from '../components/ui/Modal';
import { Input } from '../components/ui/Input';
import { Table, Column } from '../components/ui/Table';
import { User } from '../types';
import { UserPlus } from 'lucide-react';

const INITIAL_TEAM: User[] = [
  { id: 'usr-1', name: 'Sarah Chen', email: 'sarah@enterprise.io', role: 'admin', createdAt: '2026-01-15' },
  { id: 'usr-2', name: 'Alex Rivers', email: 'alex@enterprise.io', role: 'developer', createdAt: '2026-02-01' },
  { id: 'usr-3', name: 'Marcus Vance', email: 'marcus@enterprise.io', role: 'operator', createdAt: '2026-02-18' },
  { id: 'usr-4', name: 'Elena Rostova', email: 'elena@enterprise.io', role: 'developer', createdAt: '2026-03-04' },
];

export const TeamManagement: React.FC = () => {
  const [team, setTeam] = useState<User[]>(INITIAL_TEAM);
  const [modalOpen, setModalOpen] = useState(false);
  const [newMember, setNewMember] = useState({ name: '', email: '', role: 'developer' as User['role'] });

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMember.name || !newMember.email) return;
    const member: User = {
      id: `usr-${Date.now()}`,
      name: newMember.name,
      email: newMember.email,
      role: newMember.role,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setTeam([...team, member]);
    setNewMember({ name: '', email: '', role: 'developer' });
    setModalOpen(false);
  };

  const columns: Column<User>[] = [
    { key: 'name', header: 'Member Name', width: '30%' },
    { key: 'email', header: 'Email Address', width: '35%' },
    {
      key: 'role',
      header: 'Role & Permissions',
      width: '20%',
      render: (u) => (
        <Badge variant={u.role === 'admin' ? 'success' : 'info'}>
          {u.role}
        </Badge>
      ),
    },
    { key: 'createdAt', header: 'Joined', align: 'right' },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '24px', fontWeight: 800, color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>
            Team & Role-Based Access Control
          </h2>
          <p style={{ fontSize: '14px', color: 'var(--text-muted)', marginTop: '4px' }}>
            Manage operators, grant deployment permissions, and configure API access roles.
          </p>
        </div>
        <Button variant="primary" size="sm" onClick={() => setModalOpen(true)}>
          <UserPlus size={14} /> Invite Member
        </Button>
      </div>

      <Card title="Authorized Organization Members" subtitle="Users provisioned with SSO credentials.">
        <Table columns={columns} data={team} keyExtractor={(u) => u.id} />
      </Card>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Invite Team Member">
        <form onSubmit={handleAddMember}>
          <Input
            label="Full Name"
            placeholder="Jane Doe"
            required
            value={newMember.name}
            onChange={(e) => setNewMember({ ...newMember, name: e.target.value })}
          />
          <Input
            label="Work Email"
            type="email"
            placeholder="jane@enterprise.io"
            required
            value={newMember.email}
            onChange={(e) => setNewMember({ ...newMember, email: e.target.value })}
          />
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', fontSize: '12px', fontFamily: 'var(--font-mono)', textTransform: 'uppercase', color: 'var(--text-muted)', fontWeight: 600, marginBottom: '6px' }}>
              Role Assignment
            </label>
            <select
              value={newMember.role}
              onChange={(e) => setNewMember({ ...newMember, role: e.target.value as User['role'] })}
              style={{
                width: '100%',
                backgroundColor: 'var(--bg-secondary)',
                border: '1px solid var(--border-color)',
                borderRadius: '6px',
                padding: '10px 14px',
                color: 'var(--text-primary)',
                fontSize: '14px',
                outline: 'none',
              }}
            >
              <option value="developer">Developer (Read/Write)</option>
              <option value="operator">Operator (Deploy/Release)</option>
              <option value="admin">Admin (Full Control)</option>
              <option value="viewer">Viewer (Read-Only)</option>
            </select>
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
            <Button type="button" variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary">
              Send Invitation
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
