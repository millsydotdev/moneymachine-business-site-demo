import React, { useState } from 'react';
import { Card } from '../components/ui/Card';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { Table, Column } from '../components/ui/Table';
import { Badge } from '../components/ui/Badge';
import { useDebounce } from '../hooks/useDebounce';
import { Download } from 'lucide-react';

interface EventRecord {
  id: string;
  timestamp: string;
  service: string;
  event: string;
  status: '200_ok' | '400_err' | '500_err';
  latency: number;
}

const SAMPLE_EVENTS: EventRecord[] = [
  { id: 'ev-1', timestamp: '2026-11-07 14:22:10', service: 'auth-gateway', event: 'TokenVerification', status: '200_ok', latency: 4.2 },
  { id: 'ev-2', timestamp: '2026-11-07 14:22:08', service: 'vector-indexer', event: 'EmbeddingBatchIngest', status: '200_ok', latency: 48.7 },
  { id: 'ev-3', timestamp: '2026-11-07 14:21:55', service: 'billing-webhook', event: 'CheckoutSessionSuccess', status: '200_ok', latency: 12.1 },
  { id: 'ev-4', timestamp: '2026-11-07 14:21:40', service: 'rate-limiter', event: 'BurstQuotaExceeded', status: '400_err', latency: 1.1 },
  { id: 'ev-5', timestamp: '2026-11-07 14:20:12', service: 'edge-cache', event: 'CachePurgeSync', status: '200_ok', latency: 8.5 },
];

export const AnalyticsView: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const debouncedSearch = useDebounce(searchTerm, 200);

  const filteredEvents = SAMPLE_EVENTS.filter((e) =>
    e.service.toLowerCase().includes(debouncedSearch.toLowerCase()) ||
    e.event.toLowerCase().includes(debouncedSearch.toLowerCase())
  );

  const columns: Column<EventRecord>[] = [
    { key: 'timestamp', header: 'Timestamp', width: '22%' },
    { key: 'service', header: 'Microservice', width: '22%' },
    { key: 'event', header: 'Event Signature', width: '26%' },
    {
      key: 'status',
      header: 'Response',
      width: '15%',
      render: (e) => (
        <Badge variant={e.status === '200_ok' ? 'success' : 'danger'}>
          {e.status}
        </Badge>
      ),
    },
    {
      key: 'latency',
      header: 'Latency',
      align: 'right',
      render: (e) => (
        <span style={{ fontFamily: 'var(--font-mono)' }}>{e.latency.toFixed(1)} ms</span>
      ),
    },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      <div>
        <h2 style={{ fontSize: '24px', fontWeight: 800, color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>
          Real-Time Analytics & Event Stream
        </h2>
        <p style={{ fontSize: '14px', color: 'var(--text-muted)', marginTop: '4px' }}>
          Inspect low-latency transaction traces, microservice RPC calls, and error distributions.
        </p>
      </div>

      <Card
        title="Microservice Request Ledger"
        subtitle="Telemetry traces captured at the edge layer."
        headerAction={
          <div style={{ display: 'flex', gap: '8px' }}>
            <Button variant="secondary" size="sm">
              <Download size={14} /> Export CSV
            </Button>
          </div>
        }
      >
        <div style={{ marginBottom: '16px', maxWidth: '360px' }}>
          <Input
            placeholder="Filter by service or event name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <Table
          columns={columns}
          data={filteredEvents}
          keyExtractor={(e) => e.id}
          emptyMessage="No events matched your filter."
        />
      </Card>
    </div>
  );
};
