import React, { useState } from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Check } from 'lucide-react';

export const SettingsView: React.FC = () => {
  const [apiKey, setApiKey] = useLocalStorage('app_api_key', 'sk_live_enterprise_••••••••••••');
  const [endpoint, setEndpoint] = useLocalStorage('app_endpoint', 'https://api.enterprise.io/v1');
  const [savedNotice, setSavedNotice] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2000);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px', maxWidth: '800px' }}>
      <div>
        <h2 style={{ fontSize: '24px', fontWeight: 800, color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>
          System & Workspace Settings
        </h2>
        <p style={{ fontSize: '14px', color: 'var(--text-muted)', marginTop: '4px' }}>
          Configure remote API routing, edge credentials, and environment overrides.
        </p>
      </div>

      <form onSubmit={handleSave}>
        <Card title="API & Gateway Configuration" subtitle="Production endpoints for microservice communication.">
          <Input
            label="API Gateway Base URL"
            value={endpoint}
            onChange={(e) => setEndpoint(e.target.value)}
            helperText="Directs SDK calls to your local gateway or production proxy."
          />
          <Input
            label="Secret Key / Auth Token"
            type="password"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            helperText="Stored locally in browser session storage or injected via environment."
          />
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '16px' }}>
            {savedNotice ? (
              <span style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--accent-emerald)', fontSize: '13px', fontWeight: 600 }}>
                <Check size={16} /> Settings saved to local storage!
              </span>
            ) : <div />}
            <Button type="submit" variant="primary">
              Save Configuration
            </Button>
          </div>
        </Card>
      </form>

      <Card title="Architecture Integrity" subtitle="Verification details for this starter package.">
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', fontSize: '13px', fontFamily: 'var(--font-mono)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid var(--border-color)', paddingBottom: '8px' }}>
            <span style={{ color: 'var(--text-muted)' }}>REACT VERSION</span>
            <span style={{ color: 'var(--accent-emerald)', fontWeight: 600 }}>React 19.0.0</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid var(--border-color)', paddingBottom: '8px' }}>
            <span style={{ color: 'var(--text-muted)' }}>TYPESCRIPT COMPILER</span>
            <span style={{ color: 'var(--accent-emerald)', fontWeight: 600 }}>TypeScript 5.7.3</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid var(--border-color)', paddingBottom: '8px' }}>
            <span style={{ color: 'var(--text-muted)' }}>BUNDLER</span>
            <span style={{ color: 'var(--accent-emerald)', fontWeight: 600 }}>Vite 6.1.0</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ color: 'var(--text-muted)' }}>LICENSE GRANT</span>
            <span style={{ color: 'var(--text-primary)' }}>Perpetual Commercial Redistribution</span>
          </div>
        </div>
      </Card>
    </div>
  );
};
