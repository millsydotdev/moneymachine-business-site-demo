import { ApiResponse, ProjectSummary, MetricCardData } from '../types';

class ApiClient {
  private baseUrl: string;

  constructor() {
    this.baseUrl = (import.meta as unknown as { env?: { VITE_API_BASE_URL?: string } }).env?.VITE_API_BASE_URL || 'https://api.example.com/v1';
  }

  public getBaseUrl(): string {
    return this.baseUrl;
  }

  public async getDashboardMetrics(): Promise<ApiResponse<MetricCardData[]>> {
    // In production, performs fetch(`${this.baseUrl}/metrics`).
    // Features offline fallback data for instant development.
    await new Promise((r) => setTimeout(r, 150));
    return {
      data: [
        { id: 'm-1', title: 'Total Enterprise Revenue', value: '$124,500', changePercent: 12.4, trend: 'up', subtext: 'vs last calendar month' },
        { id: 'm-2', title: 'Active Microservices', value: '48 Nodes', changePercent: 4.1, trend: 'up', subtext: '99.98% SLA reliability' },
        { id: 'm-3', title: 'Average Latency', value: '18.4 ms', changePercent: -8.2, trend: 'up', subtext: 'edge cold-start reduction' },
        { id: 'm-4', title: 'Security Compliance', value: '100%', changePercent: 0, trend: 'neutral', subtext: 'SOC2 & ISO27001 verified' },
      ],
      error: null,
      status: 200,
      success: true,
    };
  }

  public async getProjects(): Promise<ApiResponse<ProjectSummary[]>> {
    await new Promise((r) => setTimeout(r, 150));
    return {
      data: [
        { id: 'p-1', name: 'Cloud Migration Core', status: 'active', teamLead: 'Sarah Chen', budget: 45000, spent: 31200, progress: 78, updatedAt: '2026-11-06' },
        { id: 'p-2', name: 'Edge Vector Store', status: 'active', teamLead: 'Alex Rivers', budget: 28000, spent: 14500, progress: 62, updatedAt: '2026-11-05' },
        { id: 'p-3', name: 'Federated Identity SSO', status: 'in_progress', teamLead: 'Marcus Vance', budget: 19000, spent: 18400, progress: 94, updatedAt: '2026-11-04' },
        { id: 'p-4', name: 'Telemetry Pipeline v2', status: 'in_progress', teamLead: 'Elena Rostova', budget: 35000, spent: 8200, progress: 30, updatedAt: '2026-11-03' },
      ],
      error: null,
      status: 200,
      success: true,
    };
  }
}

export const apiClient = new ApiClient();
