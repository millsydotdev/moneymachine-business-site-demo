import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, role?: string) => Promise<boolean>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const DEMO_USER: User = {
  id: 'usr-1',
  name: 'Lead Architect',
  email: 'architect@enterprise.io',
  role: 'admin',
  createdAt: '2026-01-15T00:00:00Z',
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem('auth_session');
    if (stored) {
      try {
        setUser(JSON.parse(stored));
      } catch {
        setUser(DEMO_USER);
      }
    } else {
      // Default to logged-in demo user for immediate developer convenience
      setUser(DEMO_USER);
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, role = 'developer'): Promise<boolean> => {
    setIsLoading(true);
    // Simulate authentication roundtrip
    await new Promise((r) => setTimeout(r, 200));
    const newUser: User = {
      id: `usr-${Date.now()}`,
      name: email.split('@')[0],
      email,
      role: role as User['role'],
      createdAt: new Date().toISOString(),
    };
    setUser(newUser);
    localStorage.setItem('auth_session', JSON.stringify(newUser));
    setIsLoading(false);
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('auth_session');
  };

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, isLoading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
