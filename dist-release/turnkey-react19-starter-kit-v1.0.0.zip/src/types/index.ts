export type UserRole = 'admin' | 'developer' | 'operator' | 'viewer';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatarUrl?: string;
  createdAt: string;
}

export interface MetricCardData {
  id: string;
  title: string;
  value: string | number;
  changePercent: number;
  trend: 'up' | 'down' | 'neutral';
  subtext: string;
}

export interface ProjectSummary {
  id: string;
  name: string;
  status: 'active' | 'in_progress' | 'archived' | 'failed';
  teamLead: string;
  budget: number;
  spent: number;
  progress: number;
  updatedAt: string;
}

export interface ApiResponse<T> {
  data: T | null;
  error: string | null;
  status: number;
  success: boolean;
}
