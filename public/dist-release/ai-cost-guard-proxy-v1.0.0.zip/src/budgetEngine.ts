// Model cost rates and budget calculation engine
export interface ModelPricing {
  promptCostPerMillion: number;
  completionCostPerMillion: number;
}

export const MODEL_PRICING_TABLE: Record<string, ModelPricing> = {
  // OpenAI
  'gpt-4o': { promptCostPerMillion: 2.50, completionCostPerMillion: 10.00 },
  'gpt-4o-mini': { promptCostPerMillion: 0.15, completionCostPerMillion: 0.60 },
  'o1-mini': { promptCostPerMillion: 3.00, completionCostPerMillion: 12.00 },
  'o1-preview': { promptCostPerMillion: 15.00, completionCostPerMillion: 60.00 },

  // Anthropic
  'claude-3-5-sonnet-20241022': { promptCostPerMillion: 3.00, completionCostPerMillion: 15.00 },
  'claude-3-5-haiku-20241022': { promptCostPerMillion: 0.80, completionCostPerMillion: 4.00 },
  'claude-3-opus-20240229': { promptCostPerMillion: 15.00, completionCostPerMillion: 75.00 },

  // Gemini
  'gemini-1.5-pro': { promptCostPerMillion: 1.25, completionCostPerMillion: 5.00 },
  'gemini-1.5-flash': { promptCostPerMillion: 0.075, completionCostPerMillion: 0.30 },
  'gemini-2.0-flash-exp': { promptCostPerMillion: 0.00, completionCostPerMillion: 0.00 }, // Free during preview

  // Fallback default
  'default': { promptCostPerMillion: 2.00, completionCostPerMillion: 8.00 },
};

export class BudgetEngine {
  private requestTimestamps: Map<string, number[]> = new Map();

  public calculateCostUsd(model: string, promptTokens: number, completionTokens: number): number {
    const pricing = MODEL_PRICING_TABLE[model] || MODEL_PRICING_TABLE['default'];
    const promptCost = (promptTokens / 1_000_000) * pricing.promptCostPerMillion;
    const completionCost = (completionTokens / 1_000_000) * pricing.completionCostPerMillion;
    return Number((promptCost + completionCost).toFixed(6));
  }

  public checkBudgetAvailable(currentSpendUsd: number, spendLimitUsd: number, estimatedCostUsd: number = 0.01): { allowed: boolean; remainingUsd: number; reason?: string } {
    const remaining = spendLimitUsd - currentSpendUsd;
    if (remaining <= 0) {
      return {
        allowed: false,
        remainingUsd: 0,
        reason: `Budget Exceeded: Current spend $${currentSpendUsd.toFixed(2)} has hit hard cap of $${spendLimitUsd.toFixed(2)}.`,
      };
    }

    if (currentSpendUsd + estimatedCostUsd > spendLimitUsd) {
      return {
        allowed: false,
        remainingUsd: Math.max(0, remaining),
        reason: `Budget Cap Limit: Projected request exceeds remaining key budget of $${remaining.toFixed(2)}.`,
      };
    }

    return { allowed: true, remainingUsd: remaining };
  }

  public checkRateLimit(virtualKey: string, limitPerMinute: number): { allowed: boolean; retryAfterSec?: number } {
    const now = Date.now();
    const windowStart = now - 60_000;

    let timestamps = this.requestTimestamps.get(virtualKey) || [];
    timestamps = timestamps.filter((t) => t > windowStart);

    if (timestamps.length >= limitPerMinute) {
      const oldestInWindow = timestamps[0];
      const retryAfterSec = Math.ceil((oldestInWindow + 60_000 - now) / 1000);
      return { allowed: false, retryAfterSec: Math.max(1, retryAfterSec) };
    }

    timestamps.push(now);
    this.requestTimestamps.set(virtualKey, timestamps);
    return { allowed: true };
  }
}
