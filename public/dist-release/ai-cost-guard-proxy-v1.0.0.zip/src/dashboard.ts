// Lightweight built-in dashboard served at GET /_guard/
import { GuardDatabase } from './db.js';

export function renderDashboardHtml(db: GuardDatabase): string {
  const summary = db.getSummary();
  const keys = db.getAllKeys();

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>AI Cost Guard & Proxy Dashboard</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: system-ui, -apple-system, sans-serif; background: #0A0D12; color: #E2E8F0; padding: 32px; }
    .container { max-width: 960px; margin: 0 auto; }
    header { border-bottom: 1px solid #1E293B; padding-bottom: 16px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; }
    h1 { font-size: 20px; font-weight: 700; color: #F8FAFC; letter-spacing: -0.01em; }
    .badge { font-family: monospace; font-size: 11px; background: rgba(16, 185, 129, 0.15); color: #10B981; border: 1px solid rgba(16, 185, 129, 0.3); padding: 4px 8px; border-radius: 4px; }
    .grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px; }
    .card { background: #111827; border: 1px solid #1F2937; border-radius: 8px; padding: 16px; }
    .card-title { font-size: 11px; text-transform: uppercase; color: #94A3B8; font-family: monospace; margin-bottom: 6px; }
    .card-val { font-size: 24px; font-weight: 700; font-family: monospace; color: #F8FAFC; }
    .emerald { color: #10B981; }
    table { width: 100%; border-collapse: collapse; background: #111827; border: 1px solid #1F2937; border-radius: 8px; overflow: hidden; font-size: 13px; font-family: monospace; }
    th { background: #1E293B; color: #94A3B8; text-align: left; padding: 12px 16px; font-weight: 600; }
    td { padding: 12px 16px; border-top: 1px solid #1F2937; }
    .progress-bar { background: #1E293B; height: 6px; border-radius: 3px; overflow: hidden; margin-top: 6px; }
    .progress-fill { height: 100%; background: #10B981; }
    .progress-fill.warn { background: #F59E0B; }
    .progress-fill.danger { background: #EF4444; }
    .key-active { color: #10B981; }
    .key-inactive { color: #EF4444; }
  </style>
</head>
<body>
  <div class="container">
    <header>
      <div>
        <h1>AI Cost Guard & Virtual Token Budget Proxy</h1>
        <p style="color: #64748B; font-size: 13px; margin-top: 4px;">Zero-dependency LLM proxy enforcing virtual API keys and hard token limits.</p>
      </div>
      <div class="badge">CIRCUIT BREAKER: ACTIVE</div>
    </header>

    <div class="grid">
      <div class="card">
        <div class="card-title">TOTAL SPEND AUDITED</div>
        <div class="card-val emerald">$${summary.totalSpendUsd.toFixed(4)}</div>
      </div>
      <div class="card">
        <div class="card-title">TOTAL TOKENS TRACKED</div>
        <div class="card-val">${summary.totalTokens.toLocaleString()}</div>
      </div>
      <div class="card">
        <div class="card-title">TOTAL PROXIED REQUESTS</div>
        <div class="card-val">${summary.totalRequests.toLocaleString()}</div>
      </div>
      <div class="card">
        <div class="card-title">ACTIVE VIRTUAL KEYS</div>
        <div class="card-val">${summary.activeKeys}</div>
      </div>
    </div>

    <h2 style="font-size: 15px; font-weight: 600; margin-bottom: 12px; color: #F1F5F9;">Virtual API Keys & Budget Allowances</h2>
    <table>
      <thead>
        <tr>
          <th>KEY ALIAS</th>
          <th>VIRTUAL KEY</th>
          <th>CURRENT SPEND / CAP</th>
          <th>UTILIZATION</th>
          <th>STATUS</th>
        </tr>
      </thead>
      <tbody>
        ${keys.map((k) => {
          const pct = Math.min(100, (k.currentSpendUsd / (k.spendLimitUsd || 1)) * 100);
          const colorClass = pct > 90 ? 'danger' : pct > 70 ? 'warn' : '';
          return `
            <tr>
              <td><strong>${k.name}</strong></td>
              <td><code>${k.key}</code></td>
              <td>$${k.currentSpendUsd.toFixed(2)} / $${k.spendLimitUsd.toFixed(2)}</td>
              <td style="width: 180px;">
                <div style="font-size: 11px; margin-bottom: 2px;">${pct.toFixed(1)}%</div>
                <div class="progress-bar">
                  <div class="progress-fill ${colorClass}" style="width: ${pct}%;"></div>
                </div>
              </td>
              <td><span class="${k.isActive ? 'key-active' : 'key-inactive'}">${k.isActive ? '● Active' : '○ Paused'}</span></td>
            </tr>
          `;
        }).join('')}
      </tbody>
    </table>
  </div>
</body>
</html>`;
}
