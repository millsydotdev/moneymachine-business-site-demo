// Database storage for AI Cost Guard Proxy
import { Database } from 'bun:sqlite';

export interface VirtualKey {
  key: string;
  name: string;
  spendLimitUsd: number;
  currentSpendUsd: number;
  rateLimitPerMin: number;
  isActive: boolean;
  createdAt: string;
}

export interface UsageLog {
  id: string;
  virtualKey: string;
  provider: string;
  model: string;
  promptTokens: number;
  completionTokens: number;
  costUsd: number;
  latencyMs: number;
  status: string;
  timestamp: string;
}

export class GuardDatabase {
  private db: Database;

  constructor(dbPath: string = 'cost_guard.db') {
    this.db = new Database(dbPath);
    this.init();
  }

  private init() {
    this.db.exec(`
      PRAGMA journal_mode = WAL;

      CREATE TABLE IF NOT EXISTS virtual_keys (
        key TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        spend_limit_usd REAL NOT NULL,
        current_spend_usd REAL DEFAULT 0.0,
        rate_limit_per_min INTEGER DEFAULT 60,
        is_active INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS usage_logs (
        id TEXT PRIMARY KEY,
        virtual_key TEXT NOT NULL,
        provider TEXT NOT NULL,
        model TEXT NOT NULL,
        prompt_tokens INTEGER NOT NULL,
        completion_tokens INTEGER NOT NULL,
        cost_usd REAL NOT NULL,
        latency_ms INTEGER NOT NULL,
        status TEXT NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE INDEX IF NOT EXISTS idx_usage_key ON usage_logs(virtual_key);
    `);

    // Seed default developer key if empty
    const countQuery = this.db.query('SELECT COUNT(*) as count FROM virtual_keys');
    const res = countQuery.get() as { count: number };
    if (res.count === 0) {
      this.createKey('vk_dev_safeguard', 'Default Dev Agent Key', 10.0, 120);
      this.createKey('vk_prod_limited', 'Staging Runner Key', 25.0, 300);
    }
  }

  public createKey(key: string, name: string, spendLimitUsd: number, rateLimitPerMin: number = 60): VirtualKey {
    const stmt = this.db.prepare(`
      INSERT INTO virtual_keys (key, name, spend_limit_usd, current_spend_usd, rate_limit_per_min, is_active)
      VALUES (?1, ?2, ?3, 0.0, ?4, 1)
      ON CONFLICT(key) DO UPDATE SET
        name = ?2,
        spend_limit_usd = ?3,
        rate_limit_per_min = ?4
    `);
    stmt.run(key, name, spendLimitUsd, rateLimitPerMin);
    return this.getKey(key)!;
  }

  public getKey(key: string): VirtualKey | null {
    const stmt = this.db.prepare(`
      SELECT key, name, spend_limit_usd, current_spend_usd, rate_limit_per_min, is_active, created_at
      FROM virtual_keys WHERE key = ?1
    `);
    const row = stmt.get(key) as any;
    if (!row) return null;
    return {
      key: row.key,
      name: row.name,
      spendLimitUsd: row.spend_limit_usd,
      currentSpendUsd: row.current_spend_usd,
      rateLimitPerMin: row.rate_limit_per_min,
      isActive: row.is_active === 1,
      createdAt: row.created_at,
    };
  }

  public getAllKeys(): VirtualKey[] {
    const stmt = this.db.prepare(`
      SELECT key, name, spend_limit_usd, current_spend_usd, rate_limit_per_min, is_active, created_at
      FROM virtual_keys ORDER BY created_at DESC
    `);
    const rows = stmt.all() as any[];
    return rows.map((row) => ({
      key: row.key,
      name: row.name,
      spendLimitUsd: row.spend_limit_usd,
      currentSpendUsd: row.current_spend_usd,
      rateLimitPerMin: row.rate_limit_per_min,
      isActive: row.is_active === 1,
      createdAt: row.created_at,
    }));
  }

  public recordUsage(log: Omit<UsageLog, 'timestamp'>): void {
    const stmt = this.db.prepare(`
      INSERT INTO usage_logs (id, virtual_key, provider, model, prompt_tokens, completion_tokens, cost_usd, latency_ms, status)
      VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9)
    `);
    stmt.run(
      log.id,
      log.virtualKey,
      log.provider,
      log.model,
      log.promptTokens,
      log.completionTokens,
      log.costUsd,
      log.latencyMs,
      log.status
    );

    // Increment current spend
    const updateKey = this.db.prepare(`
      UPDATE virtual_keys
      SET current_spend_usd = current_spend_usd + ?1
      WHERE key = ?2
    `);
    updateKey.run(log.costUsd, log.virtualKey);
  }

  public getSummary(): { totalSpendUsd: number; totalRequests: number; totalTokens: number; activeKeys: number } {
    const spendRow = this.db.query('SELECT SUM(cost_usd) as total_spend, COUNT(*) as total_reqs, SUM(prompt_tokens + completion_tokens) as total_toks FROM usage_logs').get() as any;
    const keysRow = this.db.query('SELECT COUNT(*) as count FROM virtual_keys WHERE is_active = 1').get() as any;

    return {
      totalSpendUsd: spendRow?.total_spend || 0.0,
      totalRequests: spendRow?.total_reqs || 0,
      totalTokens: spendRow?.total_toks || 0,
      activeKeys: keysRow?.count || 0,
    };
  }

  public resetKeySpend(key: string): void {
    const stmt = this.db.prepare('UPDATE virtual_keys SET current_spend_usd = 0.0 WHERE key = ?1');
    stmt.run(key);
  }

  public setKeyStatus(key: string, isActive: boolean): void {
    const stmt = this.db.prepare('UPDATE virtual_keys SET is_active = ?1 WHERE key = ?2');
    stmt.run(isActive ? 1 : 0, key);
  }
}
