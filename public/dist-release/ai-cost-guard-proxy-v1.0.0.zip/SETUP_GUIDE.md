# AI Cost Guard Proxy — Setup & Deployment Guide

## System Requirements
- Node.js 20+ or Bun 1.1+
- SQLite3 (included automatically via embedded engine)

## Installation & Launch
1. Extract release archive:
   ```bash
   unzip ai-cost-guard-proxy-v1.0.0.zip
   cd ai-cost-guard-proxy
   ```

2. Start proxy daemon:
   ```bash
   bun run src/index.ts
   ```

3. Configure Upstream API Key (Optional):
   Set `OPENAI_API_KEY` in your environment to forward live requests through upstream providers. Without an upstream key, the proxy functions in deterministic testing mode with full virtual budget enforcement.

4. Open Dashboard:
   Navigate to `http://localhost:8080/_guard` in your web browser.
