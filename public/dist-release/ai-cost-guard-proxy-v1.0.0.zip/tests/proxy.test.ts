import { describe, expect, it, beforeEach } from 'bun:test';
import { GuardDatabase } from '../src/db.js';
import { BudgetEngine } from '../src/budgetEngine.js';
import { createGuardServer } from '../src/index.js';

describe('AI Cost Guard & Proxy Engine', () => {
  const testDbPath = ':memory:';

  it('initializes database and creates virtual keys', () => {
    const db = new GuardDatabase(testDbPath);
    const key = db.createKey('vk_test_101', 'Test Agent Key', 5.0, 30);
    expect(key.key).toBe('vk_test_101');
    expect(key.spendLimitUsd).toBe(5.0);
    expect(key.currentSpendUsd).toBe(0.0);
    expect(key.isActive).toBe(true);

    const fetched = db.getKey('vk_test_101');
    expect(fetched).not.toBeNull();
    expect(fetched?.name).toBe('Test Agent Key');
  });

  it('accurately calculates token costs across models', () => {
    const budget = new BudgetEngine();

    // gpt-4o-mini: $0.15/M prompt, $0.60/M completion
    // 10,000 prompt tokens = $0.0015
    // 5,000 completion tokens = $0.0030
    // Total = $0.0045
    const costMini = budget.calculateCostUsd('gpt-4o-mini', 10_000, 5_000);
    expect(costMini).toBe(0.0045);

    // claude-3-5-sonnet: $3.00/M prompt, $15.00/M completion
    // 1,000 prompt tokens = $0.003
    // 1,000 completion tokens = $0.015
    // Total = $0.018
    const costClaude = budget.calculateCostUsd('claude-3-5-sonnet-20241022', 1_000, 1_000);
    expect(costClaude).toBe(0.018);
  });

  it('circuit breaker halts requests when budget cap is exceeded', () => {
    const budget = new BudgetEngine();

    // Cap: $10.00, Current: $9.95, Request estimated: $0.10 -> Rejects
    const checkBlocked = budget.checkBudgetAvailable(9.95, 10.0, 0.10);
    expect(checkBlocked.allowed).toBe(false);
    expect(checkBlocked.reason).toContain('Budget Cap Limit');

    // Cap: $10.00, Current: $10.00 -> Rejects
    const checkExceeded = budget.checkBudgetAvailable(10.0, 10.0, 0.001);
    expect(checkExceeded.allowed).toBe(false);
    expect(checkExceeded.reason).toContain('Budget Exceeded');

    // Cap: $10.00, Current: $2.50 -> Allows
    const checkAllowed = budget.checkBudgetAvailable(2.50, 10.0, 0.05);
    expect(checkAllowed.allowed).toBe(true);
    expect(checkAllowed.remainingUsd).toBe(7.5);
  });

  it('enforces rate limiting per minute', () => {
    const budget = new BudgetEngine();
    const testKey = 'vk_rate_test';

    // Limit: 3 requests per minute
    expect(budget.checkRateLimit(testKey, 3).allowed).toBe(true);
    expect(budget.checkRateLimit(testKey, 3).allowed).toBe(true);
    expect(budget.checkRateLimit(testKey, 3).allowed).toBe(true);

    // 4th request must be rejected
    const fourth = budget.checkRateLimit(testKey, 3);
    expect(fourth.allowed).toBe(false);
    expect(fourth.retryAfterSec).toBeGreaterThanOrEqual(1);
  });

  it('end-to-end proxy enforces auth, logs usage, and updates spend', async () => {
    const { server, db } = createGuardServer(':memory:', 8899);

    try {
      db.createKey('vk_live_test', 'Integration Test Key', 2.0, 60);

      // 1. Missing Auth header -> 401
      const resUnauth = await fetch(`http://localhost:${server.port}/v1/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: 'gpt-4o-mini', messages: [{ role: 'user', content: 'hello' }] }),
      });
      expect(resUnauth.status).toBe(401);

      // 2. Authorized request -> 200 OK + Cost header
      const resAuth = await fetch(`http://localhost:${server.port}/v1/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer vk_live_test',
        },
        body: JSON.stringify({ model: 'gpt-4o-mini', messages: [{ role: 'user', content: 'test request' }] }),
      });
      expect(resAuth.status).toBe(200);
      const data = await resAuth.json() as any;
      expect(data.choices[0].message.content).toBeDefined();

      const keyAfter = db.getKey('vk_live_test');
      expect(keyAfter?.currentSpendUsd).toBeGreaterThan(0.0);

      // 3. Manually exceed budget and verify circuit breaker triggers HTTP 429
      db.createKey('vk_exceeded', 'Exceeded Key', 0.00001, 60);
      // artificially inflate spend
      const exceedKey = db.getKey('vk_exceeded')!;
      db.recordUsage({
        id: 'log_exceeded',
        virtualKey: exceedKey.key,
        provider: 'openai',
        model: 'gpt-4o-mini',
        promptTokens: 1000,
        completionTokens: 1000,
        costUsd: 1.0,
        latencyMs: 10,
        status: 'success',
      });

      const resExceeded = await fetch(`http://localhost:${server.port}/v1/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer vk_exceeded',
        },
        body: JSON.stringify({ model: 'gpt-4o-mini', messages: [{ role: 'user', content: 'will be blocked' }] }),
      });
      expect(resExceeded.status).toBe(429);
      const errData = await resExceeded.json() as any;
      expect(errData.error.type).toBe('budget_exceeded_error');
    } finally {
      server.stop();
    }
  });
});
