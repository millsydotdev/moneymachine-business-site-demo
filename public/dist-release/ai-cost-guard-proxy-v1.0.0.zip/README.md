# AI Cost Guard & Virtual Token Budget Proxy
**Autonomous Software Factory Deliverable** · Production Release v1.0.0

## Overview
AI Cost Guard is a self-hosted, lightweight reverse proxy designed for AI engineers and autonomous agent builders. It protects against runaway LLM billing loops by placing virtual API keys with hard token limits, cost caps, and automatic circuit breakers in front of OpenAI, Anthropic, and Gemini APIs.

## Key Features
- **Virtual API Keys:** Issue scoped virtual keys (`vk_...`) for dev agents, background tasks, or team members with hard daily USD caps.
- **Circuit Breaker:** Automatically trips and returns HTTP 429 when budget limit is breached, instantly terminating recursive agent loops before burning hundreds of dollars.
- **Model Cost Telemetry:** Real-time cost calculation for GPT-4o, Claude 3.5 Sonnet, Gemini 1.5 Pro, and other models.
- **Zero Cloud Lock-in:** Local SQLite WAL storage (`cost_guard.db`) logs all requests, token usage, latency, and costs offline.
- **Embedded Web Dashboard:** Visit `http://localhost:8080/_guard` to inspect active keys, token burn rates, and trigger emergency kill switches.

## Quick Start
```bash
# 1. Install dependencies
bun install
# or
npm install

# 2. Run the proxy server
bun run src/index.ts
# or
npm run dev

# 3. Access the dashboard
open http://localhost:8080/_guard
```

## Integrating into your Agent / Client
Simply configure your OpenAI client `baseURL` to point to the proxy and use your virtual key:
```typescript
import OpenAI from 'openai';

const client = new OpenAI({
  apiKey: 'vk_dev_safeguard', // Virtual API key managed by Cost Guard
  baseURL: 'http://localhost:8080/v1',
});

// Any runaway loop exceeding your $10 cap will be safely halted!
```

## Running Tests
```bash
bun test
```
